 	<!--Done - Insert-->
  	<div class="modal fade" id="insert_Success" tabindex="-1" role="dialog" aria-labelledby="insert_alert2" aria-hidden="true">
    	<div class="modal-dialog">    
        	<div class="modal-content">
        		<div class="modal-header bg-primary">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red;">Done</strong> Your information has been successfully saved.
        		</div>
      		</div>      
		</div>
	</div><!--/.Modal--> 
    
    <!--Done - Update-->
  	<div class="modal fade" id="update_Success" tabindex="-1" role="dialog" aria-labelledby="update_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-primary">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red;">Done</strong> Your information has been successfully updated .
        		</div>
      		</div>
    	</div>
	</div><!--/.Modal-Update feedback alert 1 --> 
  
	<!--Done - Delete-->
  	<div class="modal fade" id="delete_Success" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-primary">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red;">Done</strong> Your information has been successfully deleted .
        		</div>
      		</div>
    	</div>
  	</div><!--/.Modal--> 
    
    <!--Done - Leave-->
  	<div class="modal fade" id="leave_Success" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-primary">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red;">Done</strong> The student has been successfully left .
        		</div>
      		</div>
    	</div>
  	</div><!--/.Modal--> 
    
    	<!--Done - Approve-->
  	<div class="modal fade" id="approve_Success" tabindex="-1" role="dialog" aria-labelledby="insert_alert2" aria-hidden="true">
    	<div class="modal-dialog">    
        	<div class="modal-content">
        		<div class="modal-header bg-primary">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red;">Done</strong> Petty Cash has been successfully Approved.
        		</div>
      		</div>      
		</div>
	</div><!--/.Modal-->
    
    <!--Something is wrong! - Connection Problem-->
	<div class="modal fade" id="connection_Problem" tabindex="-1" role="dialog" aria-labelledby="insert_alert3" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-purple-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red; font-size:14px">Something is wrong!</strong> Check your Internet Connection and try again.
        		</div>
      		</div>
		</div>
	</div><!--/.Modal>
    
    <!--You didn't make any changes.:D -->
  	<div class="modal fade" id="update_error1" tabindex="-1" role="dialog" aria-labelledby="update_alert2" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-green-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red;">Warning!</strong> You didn't make any changes. <strong style="color:red;">:D</strong>
        		</div>
      		</div>
    	</div>
	</div><!--/.Modal-->
     
	<!--Warning! - Classroom is Duplicated-->
	<div class="modal fade" id="classroom_Duplicated" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-red-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red; font-size:14px">Warning!</strong> This Classroom is already here .
        		</div>
			</div>
		</div>
	</div><!--/.Modal-->
    
    <!--Warning! - Grade is Duplicated-->
	<div class="modal fade" id="grade_Duplicated" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-red-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red; font-size:14px">Warning!</strong> This Grade is already here .
        		</div>
			</div>
		</div>
	</div><!--/.Modal--> 
    
    <!--Warning! - Subject is Duplicated-->
	<div class="modal fade" id="subject_Duplicated" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-red-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red; font-size:14px">Warning!</strong> This Subject is already here .
        		</div>
			</div>
		</div>
	</div><!--/.Modal--> 
    
      <!--Warning! - Exam is Duplicated-->
	<div class="modal fade" id="exam_Duplicated" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-red-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red; font-size:14px">Warning!</strong> This Exam is already here .
        		</div>
			</div>
		</div>
	</div><!--/.Modal--> 
    
    <!--Warning! - Index Number is Duplicated-->
  	<div class="modal fade" id="index_Duplicated" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-red-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red; font-size:14px">Warning!</strong> This Index Number already here .
        		</div>
      		</div>
    	</div>
	</div><!--/.Modal-->
    
    <!--Warning! - Email Address is Duplicated-->
  	<div class="modal fade" id="email_Duplicated" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-red-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red; font-size:14px">Warning!</strong> This Email Address already here .
        		</div>
      		</div>
    	</div>
	</div><!--/.Modal-->
    
    <!--Warning! - Index Number and Email Address are Duplicated-->
  	<div class="modal fade" id="index_email_Duplicated" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-red-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red; font-size:14px">Warning!</strong> This Index Number and Email Address already here .
        		</div>
      		</div>
    	</div>
	</div><!--/.Modal-->
    
    <!--Warning! - Email Address is Duplicated-->
  	<div class="modal fade" id="exam_Duplicated" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-red-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red; font-size:14px">Warning!</strong> This Exam name already here .
        		</div>
      		</div>
    	</div>
	</div><!--/.Modal-->
    
     <!--Warning! - Attendance is Duplicated-->
  	<div class="modal fade" id="attendance_Duplicated" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-red-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red; font-size:14px">Warning!</strong> Your Attendance already marked .
        		</div>
      		</div>
    	</div>
	</div><!--/.Modal-->
    
    
    <!--Warning! - For Subject Routing, -->
  	<div class="modal fade" id="duplicate_Record1" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-red-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red; font-size:14px">Warning!</strong> Duplicate Record.
        		</div>
      		</div>
    	</div>
	</div><!--/.Modal-->
    
     <!--Warning! - For the Timetable -->
  	<div class="modal fade" id="duplicate_Record2" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-red-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red; font-size:14px">Warning!</strong> At this time there is already class, in that classroom. 
        		</div>
      		</div>
    	</div>
	</div><!--/.Modal-->
    
     <!--Warning! - There heren't default image upload folder-->
  	<div class="modal fade" id="upload_error1" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-red-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red; font-size:14px">Warning!</strong> Default upload folder.
        		</div>
      		</div>
    	</div>
	</div><!--/.Modal-->	
    
     <!--Warning! - This Index Number heren't -->
  	<div class="modal fade" id="wrong_Index" tabindex="-1" role="dialog" aria-labelledby="insert_alert1" aria-hidden="true">
    	<div class="modal-dialog">    
      		<div class="modal-content">
        		<div class="modal-header bg-red-active">
          			<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
          			<h4>Information!</h4>
        		</div>
        		<div class="modal-body bgColorWhite">
        			<strong style="color:red; font-size:14px">Warning!</strong> This Index Number isn't .
        		</div>
      		</div>
    	</div>
	</div><!--/.Modal-->	