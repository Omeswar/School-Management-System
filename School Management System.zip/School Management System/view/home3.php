<head>
<title>School Management System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", sans-serif}

body, html {
  height: 100%;
  line-height: 1.8;
}

/* Full height image header */
.bgimg-1 {
  background-position: center;
  background-size: cover;
  background-image: url("../Images/home.jpg");
  min-height: 100%;
}

.w3-bar .w3-button {
  padding: 16px;
}
.open-button {
  background-color: rgb(30, 223, 230);
  color: black;
  padding: 16px 20px;
  border: none;
  bottom: 23px;
  right: 28px;
  width: 200px;
}

/* The popup form - hidden by default */
.form-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}

/* Add styles to the form container */
.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}

/* Full-width input fields */
.form-container input[type=text], .form-container input[type=password], .form-container input[type=message] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

/* When the inputs get focus, do something */
.form-container input[type=text]:focus, .form-container input[type=password]:focus, .form-container input[type=message]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit/login button */
.form-container .btn {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}

/* Add a red background color to the cancel button */
.form-container .cancel {
  background-color: red;
}

/* Add some hover effects to buttons */
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>
</head>
<body>

<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-card" id="myNavbar">
    <a href="#home" class="w3-bar-item w3-button w3-wide" style="font-family:Georgia, 'Times New Roman', Times, serif; font-size:larger;"><b>School Management System</b></a>
    <!-- Right-sided navbar links -->
    <div class="w3-right w3-hide-small">
      <a href="#about" class="w3-bar-item w3-button"><i class="fa fa-user"></i> About</a>
      <a href="#team" class="w3-bar-item w3-button"><i class="fa fa-users"></i> Head Staff</a>
      <a href="#work" class="w3-bar-item w3-button"><i class="fa fa-th"></i> Our Work</a>
      <a href="#pricing" class="w3-bar-item w3-button"><i class="fa fa-inr"></i> Fees Structure</a>
      <a href="#contact" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> Contact Us</a>
      <a href="login.php" class="w3-bar-item w3-button"><i class="fa fa-sign-out"></i>Exit</a>
    </div>
    <!-- Hide right-floated links on small screens and replace them with a menu icon -->

    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="w3_open()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
</div>

<!-- Sidebar on small screens when clicking the menu icon -->
<nav class="w3-sidebar w3-bar-block w3-black w3-card w3-animate-left w3-hide-medium w3-hide-large" style="display:none" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-bar-item w3-button w3-large w3-padding-16"><b> × </b></a>
  <a href="#about" onclick="w3_close()" class="w3-bar-item w3-button"><i class="fa fa-user"></i> About</a>
  <a href="#team" onclick="w3_close()" class="w3-bar-item w3-button"><i class="fa fa-users"></i> Head Staff</a>
  <a href="#work" onclick="w3_close()" class="w3-bar-item w3-button"><i class="fa fa-th"></i> Our Work</a>
  <a href="#pricing" onclick="w3_close()" class="w3-bar-item w3-button"><i class="fa fa-inr"></i> Fees Structure</a>
  <a href="#contact" onclick="w3_close()" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> Contact Us</a>
  <a href="login.php" onclick="w3_close()" class="w3-bar-item w3-button"><i class="fa fa-sign-out"></i> Exit</a>

</nav>
<!-- Header with full-height image -->
<header class="bgimg-1 w3-display-container w3-grayscale-min" id="home">
  <div class="w3-display-left w3-text-white" style="padding:48px">
  <p><a href="dashboard3.php" class="w3-button w3-padding-large w3-large w3-margin-top w3-hover-opacity-off" style="font-weight: bolder; background-color:darkgreen">Get Started</a></p>
  </div> 
</header>

<!-- About Section -->
<div class="space" style="padding: 10px;"></div>
<div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: rgb(245, 235, 207);">
<div class="w3-container" style="padding:20px 16px; background-color: rgb(245, 235, 207);" id="about">
  <h3 class="w3-center"><b>About</b></h3>
  <span class="w3-large">Our mission is to prepare students to contribute to and succeed in a rapidly changing society, enabling them to help make the world a better place.</span><br>
  <span class="w3-large">Education begins in the<b> Womb</b> and ends in the <b>Tomb</b>. It's theme is <b>LIFE</b>.</span>
  <p class="w3-center w3-xlarge" style="font-weight: bolder; padding: 20px;">Key features of School Management System</p>
  <div class="w3-row-padding w3-center" style="margin-top:4px">
    <div class="w3-quarter">
      <i class="fa fa-desktop w3-margin-bottom w3-jumbo w3-center" style="color: rgb(9, 199, 41);"></i>
      <p class="w3-large"><b>Responsive</b></p>
      <p>Our website is Responsive which serves all devices with the same code that adjusts for screen size.</p>
    </div>
    <div class="w3-quarter">
        <i class="fa fa-diamond w3-margin-bottom w3-jumbo" style="color: rgb(9, 199, 41);"></i>
        <p class="w3-large"><b>Design</b></p>
        <p>Our School Management System is designed to provide simplicity to all the users.</p>
      </div>
    <div class="w3-quarter">
      <i class="fa fa-heart w3-margin-bottom w3-jumbo" style="color: rgb(9, 199, 41);"></i>
      <p class="w3-large"><b>Passion</b></p>
      <p>Our passion is to provide students better and easily understandable website which helps them practically in many aspects.</p>
    </div>
    <div class="w3-quarter">
      <i class="fa fa-info-circle w3-margin-bottom w3-jumbo" style="color: rgb(9, 199, 41);"></i>
      <p class="w3-large"><b>Support</b></p>
      <p>You will be provided with 24 hrs support from admin and teachers.</p>
    </div>
  </div>
</div>
</div>
<!-- Team Section -->
<div class="space" style="padding: 10px;"></div>
<div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #c4eed5;">
<div class="w3-container" style="padding:20px 16px" id="team">
  <h3 class="w3-center"><b>Head Staff</b></h3>
  <div class="w3-row-padding w3-grayscale" style="margin-top:20px">
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-card">
        <img src="../Images/RadheShyam.jpg" alt="Admin" style="width:100%">
        <div class="w3-container">
          <h3>Prabhas Raj</h3>
          <p class="w3-opacity">Admin</p>
          <p>An admin which helps in maintaining website and records of all members in school.</p>
          <p><a href="#" class="w3-button w3-blue w3-block" style="font-weight: bolder;"><i class="fa fa-envelope"></i> Contact</a></p>
      </div>
      </div>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-card">
        <img src="../Images/Mahesh Kumar.jpg" alt="Jane" style="width:100%">
        <div class="w3-container">
          <h3>Mahesh Kumar</h3>
          <p class="w3-opacity">CEO & Co-Founder</p>
          <p>Co-Founder and CEO of our school. He helps in maintaining student relationships. </p>
          <p><button class="w3-button w3-blue w3-block"><i class="fa fa-envelope"></i><b> Contact</b></button></p>
        </div>
      </div>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-card">
        <img src="../Images/Krishnam.jpg" alt="Mike" style="width:100%">
        <div class="w3-container">
          <h3>Krishnam Raj</h3>
          <p class="w3-opacity">Principal</p>
          <p>Principal of the School. Duty-Minded. Helps in students academic results and fees.</p>
          <p><button class="w3-button w3-blue w3-block"><i class="fa fa-envelope"></i><b> Contact</b></button></p>
        </div>
      </div>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-card">
        <img src="../Images/Rajini.jpg" alt="Dan" style="width:100%">
        <div class="w3-container">
          <h3>Rajini Kanth</h3>
          <p class="w3-opacity">Head Of the Department</p>
          <p>Head of all the classes in school. He solves the problems of teachers and students.</p>
          <p><button class="w3-button w3-blue w3-block"><i class="fa fa-envelope"></i><b> Contact</b></button></p>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<!-- Promo Section "Statistics" -->
<!-- Work Section -->
<div class="space" style="padding: 10px;"></div>
<div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #dbc4ee;">
<div class="w3-container" style="padding:20px 16px" id="work">
  <h3 class="w3-center"><b>Our Work</b></h3>
  <p class="w3-center w3-large">What we've done for students</p>
  <div class="w3-row-padding" style="margin-top:20px">
    <div class="w3-col l3 m6">
      <img src="../Images/ground.jpg" style="width:100%" onclick="onClick(this)" class="w3-hover-opacity" alt="Play Ground">
    </div>
    <div class="w3-col l3 m6">
      <img src="../Images/swim.jpg" style="width:100%" onclick="onClick(this)" class="w3-hover-opacity" alt="Swimming Pools">
    </div>
    <div class="w3-col l3 m6">
      <img src="../Images/cctv.jpg" style="width:100%" onclick="onClick(this)" class="w3-hover-opacity" alt="CCTV">
    </div>
    <div class="w3-col l3 m6">
      <img src="../Images/gym.jpeg" style="width:100%" onclick="onClick(this)" class="w3-hover-opacity" alt="Gym Facility">
    </div>
  </div>

  <div class="w3-row-padding w3-section">
    <div class="w3-col l3 m6">
      <img src="../Images/cultural.jpg" style="width:100%" onclick="onClick(this)" class="w3-hover-opacity" alt="Cultural Activities">
    </div>
    <div class="w3-col l3 m6">
      <img src="../Images/bus.jpg" style="width:100%" onclick="onClick(this)" class="w3-hover-opacity" alt="Transportation Facilities">
    </div>
    <div class="w3-col l3 m6">
      <img src="../Images/Library1.jpeg" style="width:100%" onclick="onClick(this)" class="w3-hover-opacity" alt="Library">
    </div>
    <div class="w3-col l3 m6">
      <img src="../Images/motivate.jpg" style="width:100%" onclick="onClick(this)" class="w3-hover-opacity" alt="Motivation">
    </div>
  </div>
  <h3 class="w3-center"><b>Our FunBook</b></h3>
  <p>Explore our Social Media Platform <a href="../view/Funbook/Home.html" class="w3-center w3-medium"><button type="submit" class="btn btn-primary" id="btnSubmit" style="background-color:royalblue; color:whitesmoke;"> <b>FunBook</b></a></button> (Only for Beginners).</p>
</div>
</div>
<!-- Modal for full size images on click-->
<div id="modal01" class="w3-modal w3-black" onclick="this.style.display='none'">
  <span class="w3-button w3-xxlarge w3-black w3-padding-large w3-display-topright" title="Close Modal Image">×</span>
  <div class="w3-modal-content w3-animate-zoom w3-center w3-transparent w3-padding-64">
    <img id="img01" class="w3-image">
    <p id="caption" class="w3-opacity w3-large"></p>
  </div>
</div>

<!-- Skills Section -->
<div class="space" style="padding: 10px;"></div>
<div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #ffb685;">
<div class="w3-container w3-padding-20px">
  <div class="w3-row-padding">
    <div class="w3-col m6" style="padding: 50px;">
      <h3><b>Our School Ratings.</b></h3>
      <p>Our school is rated as one of the best in India.</p>
      <p>We provide innovative website for problem sloving and easy understanding.</p>
    </div>
    <div class="w3-col m6">
      <p class="w3-wide"><i class="fa fa-camera w3-margin-right"></i>Studies</p>
      <div class="w3-grey">
        <div class="w3-container w3-green w3-center" style="width:98%">98%</div>
      </div>
      <div class="space" style="padding: 10px;"></div>
      <p class="w3-wide"><i class="fa fa-desktop w3-margin-right"></i>Physical & Cultural Activities</p>
      <div class="w3-grey">
        <div class="w3-container w3-green w3-center" style="width:96%">96%</div>
      </div>
      <div class="space" style="padding: 10px;"></div>
      <p class="w3-wide"><i class="fa fa-photo w3-margin-right"></i>Facilities</p>
      <div class="w3-grey">
        <div class="w3-container w3-green w3-center" style="width:97%">97%</div>
      </div>
    </div>
  </div>
</div>
</div>
<!-- Pricing Section -->
<div class="space" style="padding: 10px;"></div>
<div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #72d1bc;">
<div class="w3-container w3-center" style="padding:20px 16px" id="pricing">
  <h3><b>Fees Structure</b></h3>
  <p class="w3-large"><b>Choose which class you want to take admission.</b></p>
  <div class="w3-row-padding" style="margin-top:20px">
    <div class="w3-third w3-section">
      <ul class="w3-ul w3-white w3-hover-shadow">
        <li class="w3-black w3-xlarge w3-padding-32">6th Class</li>
        <li class="w3-padding-16"><b>Books</b></li>
        <li class="w3-padding-16"><b>Transportation facility</b></li>
        <li class="w3-padding-16"><b>Other Facilities</b></li>
        <li class="w3-padding-16"><b>24/7 Support</b></li>
        <li class="w3-padding-16">
          <h2 class="w3-wide">Rs.1000</h2>
          <span class="w3-opacity">per year</span>
        </li>
        <li class="w3-light-grey w3-padding-24">
          <button class="w3-button w3-black w3-padding-large">Take Admission</button>
        </li>
      </ul>
    </div>
    <div class="w3-third">
      <ul class="w3-ul w3-white w3-hover-shadow">
        <li class="w3-red w3-xlarge w3-padding-48">7th class</li>
        <li class="w3-padding-16"><b>Books</b></li>
        <li class="w3-padding-16"><b>Transportation facility</b></li>
        <li class="w3-padding-16"><b>Other Facilities</b></li>
        <li class="w3-padding-16"><b>24/7 Support</b></li>
        <li class="w3-padding-16">
          <h2 class="w3-wide">Rs.1500</h2>
          <span class="w3-opacity">per year</span>
        </li>
        <li class="w3-light-grey w3-padding-24">
          <button class="w3-button w3-black w3-padding-large">Take Admission</button>
        </li>
      </ul>
    </div>
    <div class="w3-third w3-section">
      <ul class="w3-ul w3-white w3-hover-shadow">
        <li class="w3-black w3-xlarge w3-padding-32">8th Class</li>
        <li class="w3-padding-16"><b>Books</b></li>
        <li class="w3-padding-16"><b>Transportation facility</b></li>
        <li class="w3-padding-16"><b>Other Facilities</b></li>
        <li class="w3-padding-16"><b>24/7 Support</b></li>
        <li class="w3-padding-16">
          <h2 class="w3-wide">Rs.2000</h2>
          <span class="w3-opacity">per year</span>
        </li>
        <li class="w3-light-grey w3-padding-24">
          <button class="w3-button w3-black w3-padding-large">Take Admission</button>
        </li>
      </ul>
    </div>
  </div>
</div>
</div>
<!-- Contact Section -->
<div class="space" style="padding: 10px;"></div>
<div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #ccc1c1;">
<div class="w3-container" style="padding:20px 16px" id="contact">
  <h3 class="w3-center"><b>Contact Us</b></h3>
  <p class="w3-center w3-large">Lets get in touch. Send us a message:</p>
  <div style="margin-top:20px">
    <p><i class="fa fa-map-marker fa-fw w3-xxlarge w3-margin-right"></i> <b>Adress :</b> Guntur, India</p>
    <p><i class="fa fa-phone fa-fw w3-xxlarge w3-margin-right"></i> <b>Phone :</b> 9876543210</p>
    <p><i class="fa fa-envelope fa-fw w3-xxlarge w3-margin-right"> </i><b> Email :</b> admin@gmail.com</p>
    <button class="open-button" onclick="openForm()"><b>Open Form</b></button>
<div class="form-popup" id="myForm">
  <form action="#" class="form-container">
    <h1>Contact Us</h1>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>

    <label for="psw"><b>Message</b></label>
    <input type="message" placeholder="Enter Message" name="psw" required>

    <button type="submit" class="btn"><i class="fa fa-paper-plane"></i>Send Message</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
</div>
</div>
<div class="map" style="padding: 20px;">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31029.24750047002!2d78.48996773617388!3d13.55668566046315!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bb265dbe6967fc1%3A0xb63fc0bc28149f4c!2sMadanapalle%2C%20Andhra%20Pradesh!5e0!3m2!1sen!2sin!4v1647607303365!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe> </div>
</div>
</div>
<!-- Footer -->
<div class="space" style="padding: 10px;"></div>
<div class="card" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: rgb(241, 197, 74);">
<footer class="w3-center w3-padding-64">
  <a href="#home" class="w3-button w3-light-grey"><i class="fa fa-arrow-up w3-margin-right"></i>Go to the top</a>
  <div class="w3-xlarge w3-section">
    <i class="fa fa-facebook-official w3-hover-opacity"></i>
    <i class="fa fa-instagram w3-hover-opacity"></i>
    <i class="fa fa-snapchat w3-hover-opacity"></i>
    <i class="fa fa-pinterest-p w3-hover-opacity"></i>
    <i class="fa fa-twitter w3-hover-opacity"></i>
    <i class="fa fa-linkedin w3-hover-opacity"></i>
  </div>
    <strong>Copyright &copy; 2022 <a href="">Saaho Badri</a>.</strong>
</footer>
 </div>
<script>
// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}

// Toggle between showing and hiding the sidebar when clicking the menu icon
var mySidebar = document.getElementById("mySidebar");

function w3_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
  } else {
    mySidebar.style.display = 'block';
  }
}

// Close the sidebar with the close button
function w3_close() {
    mySidebar.style.display = "none";
}
</script>
<script>
    function openForm() {
      document.getElementById("myForm").style.display = "block";
    }
    
    function closeForm() {
      document.getElementById("myForm").style.display = "none";
    }
    </script>
</body>